var wms_layers = [];


        var lyr_BaseOSM_0 = new ol.layer.Tile({
            'title': 'Base OSM',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_RotaEncantosdoNorte_1 = new ol.format.GeoJSON();
var features_RotaEncantosdoNorte_1 = format_RotaEncantosdoNorte_1.readFeatures(json_RotaEncantosdoNorte_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_RotaEncantosdoNorte_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_RotaEncantosdoNorte_1.addFeatures(features_RotaEncantosdoNorte_1);
var lyr_RotaEncantosdoNorte_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_RotaEncantosdoNorte_1, 
                style: style_RotaEncantosdoNorte_1,
                interactive: false,
                title: '<img src="styles/legend/RotaEncantosdoNorte_1.png" /> Rota Encantos do Norte'
            });
var format_LimitesBairrosSoJosdoNorte_2 = new ol.format.GeoJSON();
var features_LimitesBairrosSoJosdoNorte_2 = format_LimitesBairrosSoJosdoNorte_2.readFeatures(json_LimitesBairrosSoJosdoNorte_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_LimitesBairrosSoJosdoNorte_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_LimitesBairrosSoJosdoNorte_2.addFeatures(features_LimitesBairrosSoJosdoNorte_2);
var lyr_LimitesBairrosSoJosdoNorte_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_LimitesBairrosSoJosdoNorte_2, 
                style: style_LimitesBairrosSoJosdoNorte_2,
                interactive: false,
                title: '<img src="styles/legend/LimitesBairrosSoJosdoNorte_2.png" /> Limites Bairros São José do Norte'
            });
var format_NomeBairrosSoJosdoNorte_3 = new ol.format.GeoJSON();
var features_NomeBairrosSoJosdoNorte_3 = format_NomeBairrosSoJosdoNorte_3.readFeatures(json_NomeBairrosSoJosdoNorte_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_NomeBairrosSoJosdoNorte_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_NomeBairrosSoJosdoNorte_3.addFeatures(features_NomeBairrosSoJosdoNorte_3);
var lyr_NomeBairrosSoJosdoNorte_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_NomeBairrosSoJosdoNorte_3, 
                style: style_NomeBairrosSoJosdoNorte_3,
                interactive: false,
                title: '<img src="styles/legend/NomeBairrosSoJosdoNorte_3.png" /> Nome Bairros São José do Norte'
            });
var format_LocaisSoJosdoNorte_4 = new ol.format.GeoJSON();
var features_LocaisSoJosdoNorte_4 = format_LocaisSoJosdoNorte_4.readFeatures(json_LocaisSoJosdoNorte_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_LocaisSoJosdoNorte_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_LocaisSoJosdoNorte_4.addFeatures(features_LocaisSoJosdoNorte_4);
var lyr_LocaisSoJosdoNorte_4 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_LocaisSoJosdoNorte_4, 
                style: style_LocaisSoJosdoNorte_4,
                interactive: true,
    title: 'Locais São José do Norte<br />\
    <img src="styles/legend/LocaisSoJosdoNorte_4_0.png" /> camping<br />\
    <img src="styles/legend/LocaisSoJosdoNorte_4_1.png" /> hotel<br />\
    <img src="styles/legend/LocaisSoJosdoNorte_4_2.png" /> lancheria<br />\
    <img src="styles/legend/LocaisSoJosdoNorte_4_3.png" /> padaria<br />\
    <img src="styles/legend/LocaisSoJosdoNorte_4_4.png" /> ponto turistico<br />\
    <img src="styles/legend/LocaisSoJosdoNorte_4_5.png" /> pousada<br />\
    <img src="styles/legend/LocaisSoJosdoNorte_4_6.png" /> restaurante<br />\
    <img src="styles/legend/LocaisSoJosdoNorte_4_7.png" /> rota encantos<br />'
        });

lyr_BaseOSM_0.setVisible(true);lyr_RotaEncantosdoNorte_1.setVisible(true);lyr_LimitesBairrosSoJosdoNorte_2.setVisible(true);lyr_NomeBairrosSoJosdoNorte_3.setVisible(true);lyr_LocaisSoJosdoNorte_4.setVisible(true);
var layersList = [lyr_BaseOSM_0,lyr_RotaEncantosdoNorte_1,lyr_LimitesBairrosSoJosdoNorte_2,lyr_NomeBairrosSoJosdoNorte_3,lyr_LocaisSoJosdoNorte_4];
lyr_RotaEncantosdoNorte_1.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_LimitesBairrosSoJosdoNorte_2.set('fieldAliases', {'Descriçã': 'Descriçã', 'Localidade': 'Localidade', 'Casos Soma': 'Casos Soma', 'Casos SE': 'Casos SE', 'Obitos': 'Obitos', 'Ativos': 'Ativos', });
lyr_NomeBairrosSoJosdoNorte_3.set('fieldAliases', {'Descriçã': 'Descriçã', 'Localidade': 'Localidade', 'Casos Soma': 'Casos Soma', 'Casos SE': 'Casos SE', 'Obitos': 'Obitos', 'Ativos': 'Ativos', });
lyr_LocaisSoJosdoNorte_4.set('fieldAliases', {'latitude': 'latitude', 'longitude': 'longitude', 'database': 'database', 'tipo': 'tipo', 'local': 'local', 'endereco': 'endereco', 'bairro': 'bairro', 'contato': 'contato', });
lyr_RotaEncantosdoNorte_1.set('fieldImages', {'Name': 'TextEdit', 'description': 'TextEdit', 'timestamp': 'DateTime', 'begin': 'DateTime', 'end': 'DateTime', 'altitudeMode': 'TextEdit', 'tessellate': 'Range', 'extrude': 'Range', 'visibility': 'Range', 'drawOrder': 'Range', 'icon': 'TextEdit', });
lyr_LimitesBairrosSoJosdoNorte_2.set('fieldImages', {'Descriçã': 'TextEdit', 'Localidade': 'TextEdit', 'Casos Soma': 'TextEdit', 'Casos SE': 'TextEdit', 'Obitos': 'TextEdit', 'Ativos': 'TextEdit', });
lyr_NomeBairrosSoJosdoNorte_3.set('fieldImages', {'Descriçã': 'TextEdit', 'Localidade': 'TextEdit', 'Casos Soma': 'TextEdit', 'Casos SE': 'TextEdit', 'Obitos': 'TextEdit', 'Ativos': 'TextEdit', });
lyr_LocaisSoJosdoNorte_4.set('fieldImages', {'latitude': 'TextEdit', 'longitude': 'TextEdit', 'database': 'TextEdit', 'tipo': 'TextEdit', 'local': 'TextEdit', 'endereco': 'TextEdit', 'bairro': 'TextEdit', 'contato': 'TextEdit', });
lyr_RotaEncantosdoNorte_1.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_LimitesBairrosSoJosdoNorte_2.set('fieldLabels', {'Descriçã': 'no label', 'Localidade': 'no label', 'Casos Soma': 'no label', 'Casos SE': 'no label', 'Obitos': 'no label', 'Ativos': 'no label', });
lyr_NomeBairrosSoJosdoNorte_3.set('fieldLabels', {'Descriçã': 'no label', 'Localidade': 'no label', 'Casos Soma': 'no label', 'Casos SE': 'no label', 'Obitos': 'no label', 'Ativos': 'no label', });
lyr_LocaisSoJosdoNorte_4.set('fieldLabels', {'latitude': 'no label', 'longitude': 'no label', 'database': 'no label', 'tipo': 'inline label', 'local': 'inline label', 'endereco': 'inline label', 'bairro': 'inline label', 'contato': 'inline label', });
lyr_LocaisSoJosdoNorte_4.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});